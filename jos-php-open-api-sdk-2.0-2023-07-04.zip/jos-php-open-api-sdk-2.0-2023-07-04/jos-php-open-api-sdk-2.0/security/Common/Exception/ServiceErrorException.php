<?php
namespace ACES\Common\Exception;

use Exception;

class ServiceErrorException extends Exception
{
}

