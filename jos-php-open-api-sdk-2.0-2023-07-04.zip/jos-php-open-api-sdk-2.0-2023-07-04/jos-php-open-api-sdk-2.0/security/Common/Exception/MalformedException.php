<?php
namespace ACES\Common\Exception;

use Exception;

class MalformedException extends Exception
{
}