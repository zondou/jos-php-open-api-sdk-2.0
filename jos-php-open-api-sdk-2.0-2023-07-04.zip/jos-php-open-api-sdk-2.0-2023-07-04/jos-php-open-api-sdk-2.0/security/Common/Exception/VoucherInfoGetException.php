<?php


namespace ACES\Common\Exception;


class VoucherInfoGetException extends \Exception
{

}