<?php

namespace ACES\Common\Exception;


class BrokenEnvironmentException extends CryptoException
{
}
