<?php

namespace ACES\Common\Exception;

use Exception;

class CryptoException extends Exception
{
}
