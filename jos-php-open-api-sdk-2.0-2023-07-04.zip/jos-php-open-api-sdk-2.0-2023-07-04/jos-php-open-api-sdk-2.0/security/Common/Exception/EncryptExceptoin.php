<?php
namespace ACES\Common\Exception;

class EncryptExceptoin extends \Exception
{
}

