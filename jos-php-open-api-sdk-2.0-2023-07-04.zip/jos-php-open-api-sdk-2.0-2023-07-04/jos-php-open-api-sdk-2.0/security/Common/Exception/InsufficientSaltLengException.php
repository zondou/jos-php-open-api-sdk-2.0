<?php
namespace ACES\Common\Exception;

class InsufficientSaltLengException extends \Exception
{
}

