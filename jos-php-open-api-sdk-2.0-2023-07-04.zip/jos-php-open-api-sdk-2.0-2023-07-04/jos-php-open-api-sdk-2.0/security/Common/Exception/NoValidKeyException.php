<?php
namespace ACES\Common\Exception;

use Exception;

class NoValidKeyException extends Exception
{
}

