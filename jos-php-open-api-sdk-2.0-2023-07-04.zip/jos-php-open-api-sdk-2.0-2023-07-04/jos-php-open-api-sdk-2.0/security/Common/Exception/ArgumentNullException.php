<?php
namespace ACES\Common\Exception;

class ArgumentNullException extends \Exception
{
}

