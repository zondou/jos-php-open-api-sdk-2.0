<?php
namespace ACES\Common\Exception;


class IndexCalculateException extends \Exception
{

}