<?php
namespace ACES\Common\Exception;

class InvalidKeyException extends \Exception
{
}

