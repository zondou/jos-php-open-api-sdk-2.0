<?php
namespace ACES\Common\Exception;

use Exception;

class KeyCacheOperateException extends Exception
{
}

