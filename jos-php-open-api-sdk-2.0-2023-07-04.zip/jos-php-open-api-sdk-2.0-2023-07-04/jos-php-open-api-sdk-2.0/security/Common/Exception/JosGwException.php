<?php


namespace ACES\Common\Exception;


class JosGwException extends \Exception
{

}