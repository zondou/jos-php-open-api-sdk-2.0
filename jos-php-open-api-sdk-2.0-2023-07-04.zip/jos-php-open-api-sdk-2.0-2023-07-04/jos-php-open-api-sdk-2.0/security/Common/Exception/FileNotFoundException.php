<?php
namespace ACES\Common\Exception;

class FileNotFoundException extends \Exception
{
}

