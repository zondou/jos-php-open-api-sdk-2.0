<?php
namespace ACES\Common\Exception;

class InvalidKeyPermission extends \Exception
{
}

