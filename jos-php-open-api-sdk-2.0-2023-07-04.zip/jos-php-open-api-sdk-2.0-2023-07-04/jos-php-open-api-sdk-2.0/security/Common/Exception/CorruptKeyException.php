<?php
namespace Common\Exception;
use Exception;
class CorruptKeyException extends Exception
{
}

