<?php
namespace ACES\Common\Exception;

use Exception;

class GenericException extends Exception
{
}

