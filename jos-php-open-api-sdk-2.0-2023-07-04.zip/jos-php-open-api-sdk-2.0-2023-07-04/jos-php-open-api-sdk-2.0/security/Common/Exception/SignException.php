<?php
namespace Common\Exception;

class SignException extends \Exception
{
}

