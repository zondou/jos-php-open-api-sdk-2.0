<?php
namespace ACES\Common\Exception;

use Exception;

class InvalidTokenException extends Exception
{
}