<?php

namespace ACES\Common\Exception;

class IOException extends CryptoException
{
}
