<?php
namespace ACES\Common\Exception;

class DecryptException extends \Exception
{
}

